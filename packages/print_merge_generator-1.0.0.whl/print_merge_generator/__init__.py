from .print_merge_generator import *

__doc__ = print_merge_generator.__doc__
if hasattr(print_merge_generator, "__all__"):
    __all__ = print_merge_generator.__all__